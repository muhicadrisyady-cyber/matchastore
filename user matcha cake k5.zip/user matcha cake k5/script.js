const cartBox = document.querySelector(".cart-box");
const cartEmpty = document.querySelector(".cart-empty");
const cartTotal = document.querySelector(".cart-total p");
const checkoutBtn = document.querySelector(".checkout-btn");

let totalHarga = 0;
let selectedItem = null;

// elemen modal
const qtyModal = document.getElementById("qtyModal");
const qtyInput = document.getElementById("qtyInput");
const confirmQty = document.getElementById("confirmQty");
const cancelQty = document.getElementById("cancelQty");

// buka modal
function openModal(item) {
    selectedItem = item;
    qtyInput.value = 1;
    qtyModal.style.display = "flex";
}

// tutup modal
function closeModal() {
    qtyModal.style.display = "none";
}

cancelQty.addEventListener("click", closeModal);

confirmQty.addEventListener("click", () => {
    let qty = parseInt(qtyInput.value);
    if (qty <= 0) return;

    const nama = selectedItem.querySelector("h3").innerText;
    const hargaText = selectedItem.querySelectorAll("h3")[1].innerText;
    const hargaNumber = parseInt(hargaText.replace("Rp", "").replace(".", "").trim());

    totalHarga += hargaNumber * qty;

    const item = document.createElement("p");
    item.innerText = `${nama} x${qty} — Rp ${formatRupiah(hargaNumber * qty)}`;
    cartBox.appendChild(item);

    cartEmpty.style.display = "none";
    updateTotal();

    checkoutBtn.classList.remove("disabled");
    checkoutBtn.style.opacity = "1";
    checkoutBtn.style.cursor = "pointer";

    closeModal();
});

// Klik tombol tambah ke keranjang
document.querySelectorAll(".menu-item button").forEach(btn => {
    btn.addEventListener("click", () => {
        const menuItem = btn.parentElement;
        openModal(menuItem);
    });
});

function updateTotal() {
    cartTotal.innerText = `Total: Rp ${formatRupiah(totalHarga)}`;
}

function formatRupiah(angka) {
    return angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}
checkoutBtn.addEventListener("click", () => {
    if (checkoutBtn.classList.contains("disabled")) return;

    // Generate Order ID
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const orderID = "ORD-" + randomNum;

    // Ambil pesanan sebelumnya
    let orders = JSON.parse(localStorage.getItem("orders")) || [];

    // Buat pesanan baru
    const orderData = {
        id: orderID,
        total: totalHarga,
        items: cartBox.innerHTML,
        date: new Date().toLocaleDateString("id-ID", {
            day: "numeric", month: "long", year: "numeric"
        }),
        status: "Menunggu Konfirmasi"
    };

    // Simpan ke array orders
    orders.push(orderData);
    localStorage.setItem("orders", JSON.stringify(orders));

    // Simpan juga "pesanan terakhir" agar bisa ditampilkan di halaman terima kasih
    localStorage.setItem("currentOrder", JSON.stringify(orderData));

    // Arahkan ke halaman data pemesan
    window.location.href = "data.html";
});
checkoutBtn.addEventListener("click", () => {
    if (checkoutBtn.classList.contains("disabled")) return;

    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const orderID = "ORD-" + randomNum;

    const orderData = {
        id: orderID,
        total: totalHarga,
        items: cartBox.innerHTML,
        date: new Date().toLocaleDateString("id-ID", {
            day: "numeric", month: "long", year: "numeric"
        }),
        status: "Waiting"
    };

    // Ambil data lama
    let orders = JSON.parse(localStorage.getItem("orders")) || [];

    // Tambahkan order baru
    orders.push(orderData);

    // Simpan lagi
    localStorage.setItem("orders", JSON.stringify(orders));

    window.location.href = "data.html";
});




